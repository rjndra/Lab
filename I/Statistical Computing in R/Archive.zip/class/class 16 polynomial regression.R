#covid table from class 5 scraping of wikipedia so run that code first

#quadratic linear model
# y= x+ b1x +  b2x^2
# x = t = for time for time series data

#cubic linear model
# y = a + b1x + b2x^2+ b3x^3
