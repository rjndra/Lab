summary(iris)
head(iris)

#plotting
plot(iris$Petal.Width, iris$Petal.Width)

#File > compile report