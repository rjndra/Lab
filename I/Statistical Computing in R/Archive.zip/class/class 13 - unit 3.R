x <- 1:15

GM = (x)^(1/2)

exp(mean(log(x)))

#unit 4
#chebishape inequality